package com.androidcourse.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    private EditText etEmail, etPassword, etConfirmPassword;
    private Button btnRegister;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // 初始化UI组件
        etEmail = findViewById(R.id.et_reg_email);       // 注意ID需与XML一致
        etPassword = findViewById(R.id.et_reg_password); // 注意ID需与XML一致
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        btnRegister = findViewById(R.id.btn_register);
        sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE);

        // 注册按钮点击事件
        btnRegister.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String confirmPassword = etConfirmPassword.getText().toString().trim();

            if (validateRegistration(email, password, confirmPassword)) {
                // 保存用户信息到SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("email", email);
                editor.putString("password", password);
                editor.apply();

                // 跳转回登录界面（MainActivity）
                startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                finish(); // 关闭当前注册界面
            }
        });
    }

    // 验证注册信息
    private boolean validateRegistration(String email, String password, String confirmPassword) {
        // 邮箱格式校验
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "邮箱格式错误", Toast.LENGTH_SHORT).show();
            return false;
        }
        // 密码一致性校验
        if (password.isEmpty() || !password.equals(confirmPassword)) {
            Toast.makeText(this, "密码不一致", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
