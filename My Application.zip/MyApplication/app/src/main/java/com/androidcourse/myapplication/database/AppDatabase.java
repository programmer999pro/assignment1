package com.androidcourse.myapplication.database;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.androidcourse.myapplication.model.Record;

@SuppressLint("NewApi") // 抑制 API 警告
@Database(entities = {Record.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase instance;

    public abstract RecordDao recordDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                    context.getApplicationContext(),
                    AppDatabase.class,
                    "record_database"
            ).fallbackToDestructiveMigration().build();
        }
        return instance;
    }
}