package com.androidcourse.myapplication.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "records")
public class Record {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String type;
    private double amount;
    private String remark;
    private String date;

    // 构造函数（不包含 id，Room 自动生成）
    public Record(String type, double amount, String remark, String date) {
        this.type = type;
        this.amount = amount;
        this.remark = remark;
        this.date = date;
    }

    //------------------ Getter/Setter ------------------
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}