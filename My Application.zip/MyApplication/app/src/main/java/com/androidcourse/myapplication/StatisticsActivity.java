package com.androidcourse.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.androidcourse.myapplication.database.AppDatabase;
import com.androidcourse.myapplication.database.RecordDao;
import com.androidcourse.myapplication.model.Record;
import com.google.android.material.datepicker.CalendarConstraints;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.DateValidatorPointBackward;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class StatisticsActivity extends AppCompatActivity {

    private TextView tvDateRange, tvIncomeCount, tvIncomeAmount, tvExpenseCount, tvExpenseAmount, tvTotal;
    private RecordDao recordDao;
    private String incomeLabel, expenseLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        // 初始化资源标签
        incomeLabel = getResources().getStringArray(R.array.record_types)[0];
        expenseLabel = getResources().getStringArray(R.array.record_types)[1];

        // 初始化视图
        initViews();

        // 初始化数据库
        recordDao = AppDatabase.getInstance(this).recordDao();

        // 默认加载全部数据
        loadStatistics(null, null);

        // 设置日期选择点击事件
        findViewById(R.id.iv_calendar).setOnClickListener(v -> showDateRangePicker());
    }

    private void initViews() {
        tvDateRange = findViewById(R.id.tv_date_range);
        tvIncomeCount = findViewById(R.id.tv_income_count);
        tvIncomeAmount = findViewById(R.id.tv_income_amount);
        tvExpenseCount = findViewById(R.id.tv_expense_count);
        tvExpenseAmount = findViewById(R.id.tv_expense_amount);
        tvTotal = findViewById(R.id.tv_total);
    }

    // 返回按钮点击事件
    public void onBackClick(View view) {
        finish();
    }

    // 显示日期范围选择器
    private void showDateRangePicker() {
        MaterialDatePicker<androidx.core.util.Pair<Long, Long>> picker = MaterialDatePicker.Builder
                .dateRangePicker()
                .setTitleText("选择日期范围")
                .setCalendarConstraints(buildCalendarConstraints())
                .build();

        picker.addOnPositiveButtonClickListener(selection -> {
            if (selection != null && selection.first != null && selection.second != null) {
                Long startDate = selection.first;
                Long endDate = selection.second;

                String start = formatDate(startDate);
                String end = formatDate(endDate);

                tvDateRange.setText(getString(R.string.date_range_format, start, end));
                loadStatistics(start, end);
            }
        });

        picker.show(getSupportFragmentManager(), "DATE_RANGE_PICKER");
    }

    // 允许选择任意日期（包括过去）
    private CalendarConstraints buildCalendarConstraints() {
        CalendarConstraints.Builder constraintsBuilder = new CalendarConstraints.Builder();
        constraintsBuilder.setValidator(DateValidatorPointBackward.now());
        return constraintsBuilder.build();
    }

    // 转换时间戳为日期字符串（UTC时区）
    private String formatDate(Long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(timestamp);
    }

    // 加载统计数据（含异常处理）
    private void loadStatistics(String startDate, String endDate) {
        new Thread(() -> {
            try {
                List<Record> records;
                if (startDate == null || endDate == null) {
                    records = recordDao.getAllRecordsSync();
                } else {
                    records = recordDao.getRecordsByDateRangeSync(startDate, endDate);
                }

                runOnUiThread(() -> {
                    if (records != null) {
                        updateStatisticsUI(records);
                    } else {
                        Toast.makeText(this, "数据为空", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                Log.e("StatisticsActivity", "数据库错误", e);
                runOnUiThread(() ->
                        Toast.makeText(this, "错误：" + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
            }
        }).start();
    }

    // 更新统计UI
    private void updateStatisticsUI(List<Record> records) {
        int incomeCount = 0;
        double incomeAmount = 0;
        int expenseCount = 0;
        double expenseAmount = 0;

        for (Record record : records) {
            if (incomeLabel.equals(record.getType())) {
                incomeCount++;
                incomeAmount += record.getAmount();
            } else if (expenseLabel.equals(record.getType())) {
                expenseCount++;
                expenseAmount += record.getAmount();
            }
        }

        tvIncomeCount.setText(getString(R.string.count_suffix, incomeCount));
        tvIncomeAmount.setText(getString(R.string.amount_income_prefix, incomeAmount));
        tvExpenseCount.setText(getString(R.string.count_suffix, expenseCount));
        tvExpenseAmount.setText(getString(R.string.amount_expense_prefix, expenseAmount));

        double total = incomeAmount - expenseAmount;
        String totalFormatted = total >= 0 ?
                String.format(Locale.getDefault(), "+%.2f元", total) :
                String.format(Locale.getDefault(), "%.2f元", total);
        tvTotal.setText(getString(R.string.total_label, totalFormatted));
    }
}