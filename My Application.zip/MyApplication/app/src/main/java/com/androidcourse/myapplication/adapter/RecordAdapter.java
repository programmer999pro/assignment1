package com.androidcourse.myapplication.adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.androidcourse.myapplication.R;
import com.androidcourse.myapplication.model.Record;

import java.util.List;
import java.util.Locale;

public class RecordAdapter extends RecyclerView.Adapter<RecordAdapter.ViewHolder> {
    private List<Record> recordList;

    public RecordAdapter(List<Record> recordList) {
        this.recordList = recordList;
    }

    public void setRecordList(List<Record> recordList) {
        this.recordList = recordList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_record, parent, false);
        return new ViewHolder(view);
    }

    @Override
    @SuppressLint("NewApi")
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Record record = recordList.get(position);

        holder.tvType.setText(record.getType());
        holder.tvRemark.setText(record.getRemark());
        holder.tvDate.setText(record.getDate());

        String amountText = record.getType().equals("收入")
                ? "+" + String.format(Locale.getDefault(), "%.2f", record.getAmount())
                : "-" + String.format(Locale.getDefault(), "%.2f", record.getAmount());

        holder.tvAmount.setText(amountText);

        int colorRes = record.getType().equals("收入")
                ? R.color.green_income
                : R.color.red_expense;
        holder.tvAmount.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), colorRes));
    }

    @Override
    public int getItemCount() {
        return recordList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvType, tvAmount, tvRemark, tvDate;

        public ViewHolder(View view) {
            super(view);
            tvType = view.findViewById(R.id.tv_type);
            tvAmount = view.findViewById(R.id.tv_amount);
            tvRemark = view.findViewById(R.id.tv_remark);
            tvDate = view.findViewById(R.id.tv_date);
        }
    }
}