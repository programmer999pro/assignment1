package com.androidcourse.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvRegister;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // 确保布局文件名为activity_main.xml

        // 初始化UI组件
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        tvRegister = findViewById(R.id.tv_register);
        sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE);

        // 登录按钮点击事件
        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (validateLogin(email, password)) {
                // 登录成功，跳转到主界面（需创建新Activity，如HomeActivity）
                startActivity(new Intent(MainActivity.this, HomeActivity.class));
                finish(); // 关闭当前登录界面
            } else {
                Toast.makeText(MainActivity.this, "登录失败", Toast.LENGTH_SHORT).show();
            }
        });

        // 跳转到注册界面（需创建RegisterActivity）
        tvRegister.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, RegisterActivity.class));
        });
    }

    // 验证登录信息
    private boolean validateLogin(String email, String password) {
        String savedEmail = sharedPreferences.getString("email", "");
        String savedPassword = sharedPreferences.getString("password", "");
        return email.equals(savedEmail) && password.equals(savedPassword);
    }
}