package com.androidcourse.myapplication.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import com.androidcourse.myapplication.model.Record;
import java.util.List;

@Dao
public interface RecordDao {
    @Insert
    void insert(Record record);

    @Query("SELECT * FROM records ORDER BY date DESC")
    LiveData<List<Record>> getAllRecords();

    @Query("DELETE FROM records")
    void deleteAll();

    @Query("SELECT * FROM records WHERE date BETWEEN :start AND :end")
    List<Record> getRecordsByDateRangeSync(String start, String end);

    @Query("SELECT * FROM records")
    List<Record> getAllRecordsSync();
}