package com.androidcourse.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.androidcourse.myapplication.adapter.RecordAdapter;
import com.androidcourse.myapplication.database.AppDatabase;
import com.androidcourse.myapplication.database.RecordDao;
import com.androidcourse.myapplication.model.Record;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    private RecordAdapter adapter;
    private AppDatabase database;
    private RecordDao recordDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // 初始化数据库
        database = AppDatabase.getInstance(this);
        recordDao = database.recordDao();

        // 初始化RecyclerView
        RecyclerView rvRecords = findViewById(R.id.rv_records);
        rvRecords.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecordAdapter(new ArrayList<>());
        rvRecords.setAdapter(adapter);

        // 加载数据
        loadRecords();

        // 菜单按钮点击事件
        findViewById(R.id.btn_menu).setOnClickListener(v -> showOptionsMenu(v));
    }

    // 显示右上角菜单
    private void showOptionsMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.getMenuInflater().inflate(R.menu.home_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(this);
        popup.show();
    }

    // 处理菜单点击事件
    @Override
    public boolean onMenuItemClick(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_add) {
            showAddRecordDialog();
            return true;
        } else if (id == R.id.menu_clear) {
            clearAllRecords();
            return true;
        } else if (id == R.id.menu_stats) {
            showStatistics();
            return true;
        } else if (id == R.id.menu_about) {
            showAboutDialog();
            return true;
        }
        return false;
    }

    // 从数据库加载记录
    @SuppressLint("NewApi")
    private void loadRecords() {
        recordDao.getAllRecords().observe(this, records -> {
            if (records != null) {
                adapter.setRecordList(records);
                adapter.notifyDataSetChanged();
            }
        });
    }

    // 添加新记录到数据库
    public void addNewRecord(String type, double amount, String remark, String date) {
        Record record = new Record(type, amount, remark, date);
        new Thread(() -> {
            recordDao.insert(record);
            runOnUiThread(this::loadRecords);
        }).start();
    }

    // 清空记录
    private void clearAllRecords() {
        new AlertDialog.Builder(this)
                .setTitle("确认清空")
                .setMessage("确定要清空所有记录吗？")
                .setPositiveButton("确定", (dialog, which) -> {
                    new Thread(() -> {
                        recordDao.deleteAll();
                        runOnUiThread(() -> {
                            adapter.setRecordList(new ArrayList<>());
                            adapter.notifyDataSetChanged();
                        });
                    }).start();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // 显示统计页面（新增跳转逻辑）
    private void showStatistics() {
        Intent intent = new Intent(this, StatisticsActivity.class);
        startActivity(intent);
    }

    // 显示关于对话框
    private void showAboutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("关于")
                .setMessage("记账本 v1.0\n作者：ldgdd")
                .setPositiveButton("确定", null)
                .show();
    }

    // 显示添加记录对话框
    private void showAddRecordDialog() {
        AddRecordDialog dialog = new AddRecordDialog();
        dialog.show(getSupportFragmentManager(), "AddRecordDialog");
    }
}