package com.androidcourse.myapplication;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class AddRecordDialog extends DialogFragment {
    private EditText etAmount, etRemark, etDate;
    private Spinner spType;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_add_record, null);

        spType = view.findViewById(R.id.sp_type);
        etAmount = view.findViewById(R.id.et_amount);
        etRemark = view.findViewById(R.id.et_remark);
        etDate = view.findViewById(R.id.et_date);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                requireContext(),
                R.array.record_types,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spType.setAdapter(adapter);

        builder.setView(view)
                .setTitle("添加记录")
                .setPositiveButton("确认", (dialog, which) -> {
                    String type = spType.getSelectedItem().toString();
                    String amountStr = etAmount.getText().toString().trim();
                    String remark = etRemark.getText().toString().trim();
                    String date = etDate.getText().toString().trim();

                    if (validateInput(amountStr, date)) {
                        double amount = Double.parseDouble(amountStr);
                        if (getActivity() instanceof HomeActivity) {
                            ((HomeActivity) getActivity()).addNewRecord(type, amount, remark, date);
                        }
                    }
                })
                .setNegativeButton("取消", null);

        return builder.create();
    }

    private boolean validateInput(String amountStr, String date) {
        if (amountStr.isEmpty()) {
            etAmount.setError("金额不能为空");
            return false;
        }
        try {
            Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            etAmount.setError("请输入有效数字");
            return false;
        }

        if (date.isEmpty()) {
            showToast("日期不能为空");
            return false;
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            sdf.setLenient(false);
            sdf.parse(date);
        } catch (Exception e) {
            showToast("日期格式输入有误");
            return false;
        }

        return true;
    }

    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }
}